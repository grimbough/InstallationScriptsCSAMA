## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(eval = FALSE)

## ------------------------------------------------------------------------
#  BiocInstaller::biocLite("LiNk-NY/RTCGAToolbox")
#  BiocInstaller::biocLite("waldronlab/TCGAutils")

## ------------------------------------------------------------------------
#  library(MultiAssayExperiment)
#  library(RTCGAToolbox)
#  library(TCGAutils)
#  library(readr)
#  library(RaggedExperiment)

## ------------------------------------------------------------------------
#  dataset <- getFirehoseDatasets()[27] # PRAD
#  stopifnot(identical(dataset, "PRAD"))
#  runDate <- getFirehoseRunningDates()[1]
#  analyzeDate <- getFirehoseAnalyzeDates()[1]

## ------------------------------------------------------------------------
#  buildMultiAssayExperiment <- function(TCGAcode, runDate, analyzeDate) {
#      message("\n######\n", "\nProcessing ", TCGAcode, " : )\n", "\n######\n")
#      serialpath <- file.path("data", paste0(TCGAcode, ".rds"))
#      if (file.exists(serialpath)) {
#          cancer.object <- readRDS(serialpath)
#      } else {
#          cancer.object <- getFirehoseData(TCGAcode, runDate = runDate,
#                                           gistic2_Date = analyzeDate,
#                                           RNAseq_Gene = TRUE,
#                                           Clinic = TRUE,
#                                           miRNASeq_Gene = TRUE,
#                                           RNAseq2_Gene_Norm = TRUE,
#                                           CNA_SNP = TRUE,
#                                           CNV_SNP = TRUE,
#                                           CNA_Seq = TRUE,
#                                           CNA_CGH = TRUE,
#                                           Methylation = FALSE,
#                                           Mutation = TRUE,
#                                           mRNA_Array = TRUE,
#                                           miRNA_Array = TRUE,
#                                           RPPA_Array = TRUE,
#                                           RNAseqNorm = "raw_counts",
#                                           RNAseq2Norm =
#                                               "normalized_count",
#                                           forceDownload = FALSE,
#                                           destdir = "./tmp",
#                                           fileSizeLimit = 500000,
#                                           getUUIDs = FALSE)
#          saveRDS(cancer.object, file = serialPath, compress = "bzip2")
#      }
#      ## Add clinical data from RTCGAToolbox
#      clinical.data <- Clinical(cancer.object)
#      rownames(clinical.data) <- toupper(gsub("\\.", "-",
#                                              rownames(clinical.data)))
#      clincal.data[] <- apply(clinical.data, 2, type.convert)
#  
#      ## slotNames in FirehoseData RTCGAToolbox class
#      targets <- c("RNASeqGene", "RNASeq2GeneNorm", "miRNASeqGene",
#                   "CNASNP", "CNVSNP", "CNAseq", "CNACGH", "Methylation",
#                   "mRNAArray", "miRNAArray", "RPPAArray", "Mutations",
#                   "gistica", "gistict")
#      names(targets) <- targets
#      dataList <- lapply(targets, function(datType) {
#          tryCatch({TCGAutils::TCGAextract(cancer.object, datType)},
#                   error = function(e) {
#                       message(datType, " does not contain any data!")
#                   })
#      })
#      data.full <- Filter(function(x) {!is.null(x)}, dataList)
#      for (i in seq_along(data.full)){
#          if(is(data.full[[i]], "GRangesList")){
#              data.full[[i]] <- RaggedExperiment::RaggedExperiment(data.full[[i]])
#          }
#      }
#      newmap <- generateMap(data.full, clinical.data, TCGAutils::TCGAbarcode)
#      mae <- MultiAssayExperiment(data.full, clinical.data, newmap)
#      return( mae )
#  }

## ------------------------------------------------------------------------
#  mae <- buildMultiAssayExperiment(TCGAcode=dataset, runDate=runDate,
#                                    analyzeDate=analyzeDate)

